
import { GraduationCap, Calendar, Award } from 'lucide-react';

const education = [
  {
    institution: "PES University",
    degree: "Master of Business Administration, Business Analytics",
    duration: "2017 - 2019",
    grade: "8",
    logo: "/lovable-uploads/a4c3a3e5-a8e7-4fbe-a051-19f8295d4d3f.png",
    skills: ["Salesforce Customization", "Level -1", "Business Analytics"]
  },
  {
    institution: "Visvesvaraya Technological University",
    degree: "Bachelor's degree, Computer Science",
    duration: "2010 - 2014",
    logo: "/placeholder.svg",
    skills: []
  },
];

const awards = [
  {
    title: "Xcelerate Warrior",
    issuer: "Tata Consultancy Services",
    date: "Dec 2023",
    description: "This Xcelerate Warrior award recognises an individual who has been influential and has significantly contributed to making a visible difference."
  }
];

const EducationSection = () => {
  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">Education</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-white rounded-md shadow-sm overflow-hidden flex items-center justify-center">
                      <img 
                        src={edu.logo}
                        alt={edu.institution}
                        className="w-10 h-10 object-contain"
                      />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-salesforce-navy">{edu.institution}</h3>
                      <p className="text-salesforce-blue">{edu.degree}</p>
                      
                      <div className="flex items-center text-sm text-gray-600 mt-1">
                        <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                        {edu.duration}
                      </div>
                      
                      {edu.grade && (
                        <p className="text-sm text-gray-600 mt-1">
                          Grade: {edu.grade}
                        </p>
                      )}
                      
                      {edu.skills.length > 0 && (
                        <div className="mt-3">
                          <h4 className="text-xs font-medium text-gray-500 mb-2">Skills</h4>
                          <div className="flex flex-wrap gap-1">
                            {edu.skills.map((skill, skillIndex) => (
                              <span 
                                key={skillIndex}
                                className="text-xs bg-blue-50 text-salesforce-navy px-2 py-1 rounded"
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-salesforce-navy mb-6 flex items-center">
              <Award className="w-5 h-5 mr-2 text-salesforce-blue" />
              Honors & Awards
            </h3>
            
            <div className="space-y-6">
              {awards.map((award, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border-l-4 border-salesforce-blue hover:shadow-lg transition-shadow"
                >
                  <h4 className="text-lg font-semibold text-salesforce-navy">{award.title}</h4>
                  <p className="text-sm text-salesforce-blue">
                    {award.issuer} • {award.date}
                  </p>
                  
                  {award.description && (
                    <p className="text-gray-700 mt-2">
                      {award.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
