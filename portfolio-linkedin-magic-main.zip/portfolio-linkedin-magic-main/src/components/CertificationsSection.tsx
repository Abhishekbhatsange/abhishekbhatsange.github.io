
import { Award, ExternalLink } from 'lucide-react';

const certifications = [
  {
    title: "Salesforce Certified Associate",
    issuer: "Salesforce",
    date: "Aug 2023",
    logo: "/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png",
    credentialId: "3634388",
    skills: ["Salesforce", "Software as a Service (SaaS)", "Salesforce Training", "Salesforce.com Administration"]
  },
  {
    title: "Salesforce Certified Administrator (SCA)",
    issuer: "Salesforce",
    date: "Mar 2023",
    logo: "/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png",
    credentialId: "3119111",
    skills: ["Database Administration", "Administration", "Salesforce.com Administration"]
  },
  {
    title: "Salesforce Certified Platform Developer I",
    issuer: "Salesforce",
    date: "May 2023",
    logo: "/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png",
    credentialId: "3333485",
    skills: ["Salesforce", "Salesforce.com", "Salesforce Sales Cloud", "Salesforce.com Consulting", "Salesforce.com Development", "Certified Salesforce.com Developer", "Salesforce.com Implementation", "Salesforce Lightning"]
  },
  {
    title: "Salesforce Certified Platform App Builder Certification",
    issuer: "Salesforce",
    date: "Sep 2023",
    logo: "/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png",
    credentialId: "3665349",
    skills: ["Software development knowledge", "Agile Methodologies", "Agile Project Management", "App builder"]
  },
  {
    title: "Business Analyst and Project Manager Collaboration",
    issuer: "Project Management Institute",
    date: "Sep 2023",
    logo: "/lovable-uploads/b4c2859e-bdda-4ce7-90d9-8931ce29573f.png",
    credentialId: "c6e1df26d912a497a3cc0988f8c6a34fc7b8a0c1b4e7ae27a0aa2851a26e1e3",
    skills: ["Business Analytics", "Cross-functional Collaborations", "Project Management"]
  },
  {
    title: "Emerging Leaders Global Capstone Session",
    issuer: "Harvard Business Publishing Corporate Learning",
    date: "Apr 2025",
    logo: "/placeholder.svg",
    credentialId: "",
    skills: ["Leadership", "Behavior Management", "Organizational Leadership", "Management"]
  },
  {
    title: "Zero to Hero in Lightning Web Components",
    issuer: "Udemy",
    date: "Feb 2024",
    logo: "/placeholder.svg",
    credentialId: "",
    skills: ["Lightning Web Components", "JavaScript"]
  },
  {
    title: "Agile Fundamentals : Including Scrum & Kanban",
    issuer: "Udemy",
    date: "Mar 2024",
    logo: "/placeholder.svg",
    credentialId: "",
    skills: ["Agile Methodologies", "Agile Project Management", "Agile Environment"]
  },
];

const CertificationsSection = () => {
  return (
    <section id="certifications" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="section-title">Certifications</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certifications.map((cert, index) => (
            <div 
              key={index}
              className="certification-card animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start space-x-4 mb-4">
                <div className="w-12 h-12 bg-white rounded-md shadow-sm overflow-hidden flex items-center justify-center">
                  <img 
                    src={cert.logo}
                    alt={cert.issuer}
                    className="w-10 h-10 object-contain"
                  />
                </div>
                <div>
                  <h3 className="font-semibold text-salesforce-navy">{cert.title}</h3>
                  <p className="text-sm text-salesforce-blue">{cert.issuer}</p>
                  <p className="text-xs text-gray-500">Issued {cert.date}</p>
                  
                  {cert.credentialId && (
                    <p className="text-xs text-gray-500 mt-1">
                      Credential ID: {cert.credentialId}
                    </p>
                  )}
                </div>
              </div>
              
              {cert.skills.length > 0 && (
                <div>
                  <h4 className="text-xs font-medium text-gray-500 mb-2">Skills</h4>
                  <div className="flex flex-wrap gap-1">
                    {cert.skills.map((skill, skillIndex) => (
                      <span 
                        key={skillIndex}
                        className="text-xs bg-blue-50 text-salesforce-navy px-2 py-1 rounded"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <div className="inline-flex items-center justify-center p-4 rounded-lg bg-blue-50">
            <Award className="w-5 h-5 text-salesforce-blue mr-2" />
            <span className="text-salesforce-navy font-medium">
              Trailhead Double Star Ranger (x2)
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CertificationsSection;
