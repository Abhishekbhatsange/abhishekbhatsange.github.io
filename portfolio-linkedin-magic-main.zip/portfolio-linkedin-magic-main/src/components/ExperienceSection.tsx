
import { 
  Briefcase, 
  Calendar,
  MapPin,
} from 'lucide-react';

const experiences = [
  {
    title: "Salesforce Consultant",
    company: "Capgemini",
    logo: "/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png",
    duration: "May 2024 - Present",
    location: "Bengaluru, Karnataka, India",
    type: "Full-time",
    description: [],
  },
  {
    title: "Salesforce Developer",
    company: "Tata Consultancy Services",
    logo: "/lovable-uploads/7e45b3d6-a747-4513-9544-4deae9a90641.png",
    duration: "Dec 2022 - May 2024",
    location: "Bengaluru, Karnataka, India",
    type: "Full-time",
    description: [],
  },
  {
    title: "Salesforce Developer",
    company: "Mindtree",
    logo: "/lovable-uploads/480f7407-e328-4d58-9e2b-c26ce189c7c5.png",
    duration: "Jun 2020 - Jun 2022",
    location: "Bengaluru, Karnataka, India",
    type: "Full-time",
    description: [],
  },
  {
    title: "Talent Acquisition and Brand Management Intern - (MBA internship)",
    company: "ZapCom Group",
    logo: "/lovable-uploads/7d72d1b8-e558-4e96-aa58-9f1081432c37.png",
    duration: "Mar 2019 - Jun 2019",
    location: "Bengaluru, Karnataka, India",
    type: "Internship",
    description: [
      "Recruiting employees whose talents are aligned with business goals and Brand Management such as creating a positive brand value among the employees, interviewees and Audiences.",
      "Skills: Technical Recruiting · Strategic Planning"
    ],
  },
  {
    title: "Client Relationship Management Intern - (MBA internship)",
    company: "Encycle India Private Limited",
    logo: "/placeholder.svg",
    duration: "Sep 2018 - Dec 2018",
    location: "Bengaluru, Karnataka, India",
    type: "Internship",
    description: [
      "Manage and analyze client interactions and data throughout the deal lifecycle, with the goal of improving client service relationships and assisting in client retention and driving sales growth.",
      "Skills: Organizational Development · Brand Development"
    ],
  },
  {
    title: "Research Investigator - (MBA internship)",
    company: "PES University",
    logo: "/lovable-uploads/a4c3a3e5-a8e7-4fbe-a051-19f8295d4d3f.png",
    duration: "Mar 2018 - Sep 2018",
    location: "Bengaluru, Karnataka, India",
    type: "Internship",
    description: [
      "Project Title - Sexual Health Education.",
      "ICSSR - Indian Council of Social Science Research.",
      "Skills: Social Awareness"
    ],
  },
  {
    title: "System Engineer",
    company: "Hewlett Packard Enterprise",
    logo: "/lovable-uploads/ed181b19-ce96-4ed0-b8a4-ba3e8df6867b.png",
    duration: "Feb 2015 - Mar 2017",
    location: "Bengaluru, Karnataka, India",
    type: "Full-time",
    description: [],
  },
];

const ExperienceSection = () => {
  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="section-title">Professional Experience</h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-1 bg-salesforce-blue"></div>
          
          {/* Experience cards */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div 
                key={index}
                className={`relative flex flex-col md:flex-row ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-white border-2 border-salesforce-blue z-10"></div>
                
                {/* Card */}
                <div className="ml-6 md:ml-0 md:w-5/12 pl-0 md:pl-6 md:pr-6">
                  <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 flex-shrink-0 bg-white rounded-md shadow-sm overflow-hidden flex items-center justify-center">
                        <img 
                          src={exp.logo} 
                          alt={exp.company} 
                          className="w-10 h-10 object-contain"
                        />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-salesforce-navy">{exp.title}</h3>
                        <p className="text-salesforce-blue font-medium">{exp.company}</p>
                        <p className="text-sm text-gray-500">{exp.type}</p>
                        
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center text-sm text-gray-600">
                            <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                            {exp.duration}
                          </div>
                          <div className="flex items-center text-sm text-gray-600">
                            <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                            {exp.location}
                          </div>
                        </div>
                        
                        {exp.description.length > 0 && (
                          <div className="mt-3 space-y-2">
                            {exp.description.map((desc, i) => (
                              <p key={i} className="text-sm text-gray-700">{desc}</p>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
