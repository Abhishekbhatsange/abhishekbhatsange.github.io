
import { User, Coffee, Globe, Clock } from 'lucide-react';

const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">About Me</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-2">
            <p className="text-gray-700 mb-4">
              Experienced and Passionate Salesforce Developer with a demonstrated history of working in the information technology
              and services industry.
            </p>
            <ul className="space-y-2 text-gray-700 list-disc pl-5">
              <li>
                Salesforce Certified Developer and Administrator, Trailhead Double star Ranger (x2), Experienced Sales Cloud, Service
                Cloud, Community Cloud, Marketing Cloud Developer and Business Analyst.
              </li>
              <li>
                Extensive working experience in Sales Cloud, Service Cloud and Community Cloud: Lightning Web Component (LWC),
                Apex, Visualforce, Restful API, SOQL, JavaScript, HTML, CSS, Salesforce Admin part (Flow, Process Builder, Workflow Rule,
                Data Modelling, etc.), Experience Builder, etc.
              </li>
              <li>
                Working experience in Marketing Cloud: Automations, Journey Builder, AMP Script, Email Studio,
                Data Extension, Analytics Builder, Query Studio, etc.
              </li>
              <li>
                Extensive experience working in Test Driven Development and Agile Development.
              </li>
              <li>
                Experience in interacting with various business user groups for gathering the requirements for salesforce.com CRM
                project implementation and Data Centralization.
              </li>
              <li>
                Past working experience in Java/J2ee application development including Core Java, Spring Framework, Hibernate, SQL,
                Junit, Collection, Solace, Jenkins, UNIX, etc.
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-1">
            <div className="bg-gradient-to-br from-salesforce-sky to-blue-100 rounded-lg p-6 shadow-md">
              <h3 className="text-xl font-semibold text-salesforce-navy mb-4">Personal Info</h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <User className="w-5 h-5 mt-1 mr-3 text-salesforce-blue" />
                  <div>
                    <h4 className="font-medium text-salesforce-navy">Name</h4>
                    <p className="text-gray-700">Abhishek Bhatsange</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Coffee className="w-5 h-5 mt-1 mr-3 text-salesforce-blue" />
                  <div>
                    <h4 className="font-medium text-salesforce-navy">Role</h4>
                    <p className="text-gray-700">Salesforce Developer</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Globe className="w-5 h-5 mt-1 mr-3 text-salesforce-blue" />
                  <div>
                    <h4 className="font-medium text-salesforce-navy">Location</h4>
                    <p className="text-gray-700">Bengaluru, Karnataka, India</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Clock className="w-5 h-5 mt-1 mr-3 text-salesforce-blue" />
                  <div>
                    <h4 className="font-medium text-salesforce-navy">Experience</h4>
                    <p className="text-gray-700">4+ Years in Salesforce</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
