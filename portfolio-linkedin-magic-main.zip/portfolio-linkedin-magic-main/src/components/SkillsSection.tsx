
import { Code, Database, Server, Cpu, Monitor, GitBranch, Trello, Users } from 'lucide-react';

const SkillsSection = () => {
  const skillCategories = [
    {
      name: "Salesforce Technologies",
      icon: <Monitor className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Sales Cloud", "Service Cloud", "Community Cloud", "Marketing Cloud", 
        "Salesforce Admin", "Salesforce Customization", "Data Modeling",
        "Experience Builder", "Flow", "Process Builder", "Workflow Rules"
      ]
    },
    {
      name: "Development",
      icon: <Code className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Lightning Web Components (LWC)", "Apex", "Visualforce", "JavaScript", 
        "HTML", "CSS", "SOQL", "REST API", "Java", "Spring Framework", "Hibernate"
      ]
    },
    {
      name: "Administration",
      icon: <Database className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Salesforce Administration", "Database Administration", "User Management",
        "Security Controls", "Sharing Rules", "Role Hierarchy", "Permission Sets"
      ]
    },
    {
      name: "Methodologies",
      icon: <Trello className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Agile Methodologies", "Scrum", "Kanban", "Test Driven Development",
        "Software Development Life Cycle (SDLC)", "Project Management"
      ]
    },
    {
      name: "Tools & Platforms",
      icon: <Server className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Salesforce Lightning Platform", "VSCode", "Developer Console", "Git",
        "Jenkins", "JIRA", "Salesforce DX", "Journey Builder", "Email Studio"
      ]
    },
    {
      name: "Analytics & Business",
      icon: <Cpu className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Business Analytics", "CRM Analytics", "Query Studio", "Predictive Analytics",
        "Business Analysis", "Requirements Gathering", "Client Relationship Management"
      ]
    },
    {
      name: "Collaboration",
      icon: <Users className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Cross-functional Collaboration", "Business User Interaction", "Stakeholder Management",
        "Technical Documentation", "Knowledge Transfer", "Mentoring"
      ]
    },
    {
      name: "DevOps",
      icon: <GitBranch className="w-5 h-5 text-salesforce-blue" />,
      skills: [
        "Version Control", "Git", "CI/CD", "Change Sets", "Deployment Strategies",
        "Release Management", "Environment Management"
      ]
    },
  ];

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">Skills & Expertise</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {skillCategories.map((category, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg shadow-md p-6 border-l-4 border-salesforce-blue hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 bg-blue-50 rounded-md">
                  {category.icon}
                </div>
                <h3 className="text-lg font-semibold text-salesforce-navy">{category.name}</h3>
              </div>
              
              <div className="flex flex-wrap">
                {category.skills.map((skill, skillIndex) => (
                  <span key={skillIndex} className="skill-badge">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16">
          <h3 className="text-xl font-bold text-salesforce-navy mb-6">Top Skills</h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              { name: "Salesforce Development", level: 95 },
              { name: "Apex", level: 90 },
              { name: "Lightning Web Components", level: 90 },
              { name: "SOQL", level: 95 },
              { name: "JavaScript", level: 85 },
              { name: "API Integration", level: 85 },
              { name: "Salesforce Administration", level: 90 },
              { name: "Agile Methodologies", level: 80 },
            ].map((skill, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                  <span className="text-sm font-medium text-salesforce-blue">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-salesforce-blue h-2.5 rounded-full" 
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
