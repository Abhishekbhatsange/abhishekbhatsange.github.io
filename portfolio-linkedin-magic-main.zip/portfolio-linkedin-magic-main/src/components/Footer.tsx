
import { Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-salesforce-navy text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-bold">Abhishek Bhatsange</h3>
            <p className="text-gray-300">Salesforce Developer</p>
          </div>
          
          <div className="text-center mb-4 md:mb-0">
            <p className="text-gray-300">
              Built with <Heart className="inline-block w-4 h-4 text-red-500" /> using React & Tailwind CSS
            </p>
            <a 
              href="https://abhishekbhatsange.github.io" 
              className="text-blue-300 hover:text-blue-200 text-sm"
              target="_blank"
              rel="noopener noreferrer"
            >
              abhishekbhatsange.github.io
            </a>
          </div>
          
          <div className="text-gray-300">
            <p>&copy; {currentYear} All Rights Reserved</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
