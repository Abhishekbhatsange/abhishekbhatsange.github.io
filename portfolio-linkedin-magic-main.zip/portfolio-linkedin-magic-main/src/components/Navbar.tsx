
import { useState } from 'react';
import { Menu, X, Linkedin, Mail, Github } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm py-4 sticky top-0 z-50">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <a href="#hero" className="text-xl font-bold text-salesforce-navy">
          Abhishek Bhatsange
        </a>
        
        {/* Desktop menu */}
        <div className="hidden md:flex items-center space-x-8">
          <a href="#about" className="text-gray-600 hover:text-salesforce-blue transition-colors">About</a>
          <a href="#experience" className="text-gray-600 hover:text-salesforce-blue transition-colors">Experience</a>
          <a href="#skills" className="text-gray-600 hover:text-salesforce-blue transition-colors">Skills</a>
          <a href="#certifications" className="text-gray-600 hover:text-salesforce-blue transition-colors">Certifications</a>
          <a href="#education" className="text-gray-600 hover:text-salesforce-blue transition-colors">Education</a>
          <a href="#contact" className="text-gray-600 hover:text-salesforce-blue transition-colors">Contact</a>
        </div>
        
        <div className="hidden md:flex items-center space-x-4">
          <a href="https://www.linkedin.com/in/abhishek-bhatsange" target="_blank" rel="noopener noreferrer">
            <Linkedin className="w-5 h-5 text-gray-600 hover:text-salesforce-blue transition-colors" />
          </a>
          <a href="mailto:abhishek.bhatsange@example.com" target="_blank" rel="noopener noreferrer">
            <Mail className="w-5 h-5 text-gray-600 hover:text-salesforce-blue transition-colors" />
          </a>
          <a href="https://github.com/abhishek-bhatsange" target="_blank" rel="noopener noreferrer">
            <Github className="w-5 h-5 text-gray-600 hover:text-salesforce-blue transition-colors" />
          </a>
        </div>
        
        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle Menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-white shadow-md py-4 px-4 flex flex-col space-y-4 animate-fade-in">
          <a 
            href="#about" 
            className="text-gray-600 hover:text-salesforce-blue transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            About
          </a>
          <a 
            href="#experience" 
            className="text-gray-600 hover:text-salesforce-blue transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Experience
          </a>
          <a 
            href="#skills" 
            className="text-gray-600 hover:text-salesforce-blue transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Skills
          </a>
          <a 
            href="#certifications" 
            className="text-gray-600 hover:text-salesforce-blue transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Certifications
          </a>
          <a 
            href="#education" 
            className="text-gray-600 hover:text-salesforce-blue transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Education
          </a>
          <a 
            href="#contact" 
            className="text-gray-600 hover:text-salesforce-blue transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </a>
          <div className="flex items-center space-x-4 pt-2">
            <a href="https://www.linkedin.com/in/abhishek-bhatsange" target="_blank" rel="noopener noreferrer">
              <Linkedin className="w-5 h-5 text-gray-600 hover:text-salesforce-blue transition-colors" />
            </a>
            <a href="mailto:abhishek.bhatsange@example.com" target="_blank" rel="noopener noreferrer">
              <Mail className="w-5 h-5 text-gray-600 hover:text-salesforce-blue transition-colors" />
            </a>
            <a href="https://github.com/abhishek-bhatsange" target="_blank" rel="noopener noreferrer">
              <Github className="w-5 h-5 text-gray-600 hover:text-salesforce-blue transition-colors" />
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
