
import { ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <section id="hero" className="min-h-screen flex flex-col justify-center relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="bg-gradient-to-br from-white via-salesforce-sky to-blue-100 h-full w-full opacity-70"></div>
        <div className="absolute inset-0 bg-[url('/lovable-uploads/da74468f-7fb2-46d9-b9b4-fd2bd6603a9f.png')] bg-cover bg-center opacity-20"></div>
      </div>
      
      <div className="container mx-auto px-4 z-10 py-16">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/3 flex justify-center">
            <div className="w-60 h-60 rounded-full overflow-hidden border-4 border-white shadow-xl">
              <img 
                src="/lovable-uploads/b82e8736-43b8-43ba-a570-0151d379b2ca.png" 
                alt="Abhishek Bhatsange" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          <div className="md:w-2/3 text-center md:text-left">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-salesforce-navy animate-fade-in">
                Abhishek Bhatsange
              </h1>
              <h2 className="text-xl md:text-2xl text-salesforce-blue font-medium animate-fade-in animate-delay-100">
                Salesforce Developer at Capgemini
              </h2>
              <p className="text-gray-600 max-w-2xl animate-fade-in animate-delay-200">
                Experienced and Passionate Salesforce Developer with a demonstrated history of working in the information technology and services industry. Multiple Salesforce certifications and expertise in cloud solutions.
              </p>
              
              <div className="flex flex-wrap gap-3 justify-center md:justify-start animate-fade-in animate-delay-300">
                <div className="flex items-center bg-white rounded-full px-3 py-1.5 shadow-sm">
                  <img src="/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png" alt="Salesforce Certified" className="w-6 h-6 mr-2" />
                  <span className="text-sm font-medium">Salesforce Certified Associate</span>
                </div>
                <div className="flex items-center bg-white rounded-full px-3 py-1.5 shadow-sm">
                  <img src="/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png" alt="Salesforce Certified" className="w-6 h-6 mr-2" />
                  <span className="text-sm font-medium">Salesforce Certified Administrator</span>
                </div>
                <div className="flex items-center bg-white rounded-full px-3 py-1.5 shadow-sm">
                  <img src="/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png" alt="Salesforce Certified" className="w-6 h-6 mr-2" />
                  <span className="text-sm font-medium">Platform Developer I</span>
                </div>
                <div className="flex items-center bg-white rounded-full px-3 py-1.5 shadow-sm">
                  <img src="/lovable-uploads/ceb954d7-8e84-4f17-a14b-39df24b38920.png" alt="Salesforce Certified" className="w-6 h-6 mr-2" />
                  <span className="text-sm font-medium">Platform App Builder</span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-3 animate-fade-in animate-delay-400 pt-4 justify-center md:justify-start">
                <Button className="bg-salesforce-blue hover:bg-salesforce-navy">
                  <a href="#contact">Contact Me</a>
                </Button>
                <Button variant="outline" className="border-salesforce-blue text-salesforce-blue hover:bg-salesforce-sky hover:text-salesforce-navy">
                  <a href="#experience">View Experience</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <a href="#about" aria-label="Scroll down">
            <ArrowDown className="w-6 h-6 text-salesforce-blue" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
